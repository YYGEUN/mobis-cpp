#include <iostream>
using namespace std;
class CString
{
	private:
	   char* m_str;
	   int m_length;
	public:
	CString();
	CString(char* str);
	CString(const CString& string);
	CString operator=(CString& string);
	CString operator=(char* str);

	~CString();
	int GetLength();
	char GetAt(int position);


	CString operator+(CString& string);
	CString operator+(char* str);
	CString operator+=(CString& string);
	CString operator+=(char* str);


	bool operator!=(CString& string);
	bool operator!=(char* str);
	bool operator==(CString& string);
	bool operator==(char* str);
	friend ostream& operator<<(ostream&, CString&r );
}; 
 
int main()
{
	CString str1("abcdefg");
	CString str2 = "abcdefg";
	str1 = "abcdefg";
	str2 = str1;
	CString str3 = str1;
	cout << "str1=" << str1 << endl;
	cout << "str2=" << str2 << endl;
	cout << "str3=" << str3 << endl;


	str1 = "ag";
	cout << "str1= ag :" << str1 << endl;
	str1 += str2;  //문자열연결( strcat, sprintf)
	cout << "str1 += str2 :" << str1 << endl;
	str1 += "et";  //문자열연결( strcat, sprintf)
	cout << "str1 + et :" << str1 << endl;

	str1 = str2 + str3;  //문자열연결( strcat, sprintf)
	cout << "str1 = str2 + str3 : " << str1 << endl;
	str1 = str2 + "rh";  //문자열연결( strcat, sprintf)
	cout << "str2 + rh : " << str1 << endl;


	CString str4("tbcdefg"); 
	cout << str1.GetLength() << endl; //문자갯수
	cout << str1.GetAt(2) << endl; //2번째문자 

	if( str1 == str4)
	   cout << "두개의 문자가 같음" << endl;
	else
	   cout << "두개의 문자가 틀림" << endl;

	if( str1 != str4)
	   cout << "두개의 문자가 틀림" << endl;
	else
	   cout << "두개의 문자가 같음" << endl;
	   
	if( str1 == "abc")
	   cout << "두개의 문자가 같음" << endl;
	else
	   cout << "두개의 문자가 틀림" << endl;

	if( str1 != "abc")
	   cout << "두개의 문자가 틀림" << endl;
	else
	   cout << "두개의 문자가 같음" << endl;
	return 0;
}