#include <iostream>
#include <string>
using namespace std;

/*
��ȯ�� operator������(�Ű� ���� ���)
{
	....// ���� ����
}
*/

class Test {
private:
	int a; int b;
public:
	Test() {
		this->a = 0; this->b = 0;
		cout << "constructor call" << endl;
	}
	Test(int x, int y) {
		a = x; b = y;
		cout << "arg constructor call" << endl;
	}
	~Test() {cout << "dest call" << endl;}
	void setData(int x, int y) {
		a = x;b = y;
	}
	void show() {cout << "a=" << a << " b=" << b << endl;}

};
int main() {


	return 0;
}