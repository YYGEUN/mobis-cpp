#include "HomeAutomationSystem.h"

int main()
{
	HomeAutomationSystem has;

	return 0;
}